ServletContext context = getServletContext();
context.setAttribute("appName", "MyServletApp");
