public void init(ServletConfig config) throws ServletException {
    String dbUrl = config.getInitParameter("dbURL");
}
