HttpSession session = request.getSession();
session.setAttribute("theme", "dark");
