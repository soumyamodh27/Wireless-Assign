Cookie cookie = new Cookie("username", "JohnDoe");
response.addCookie(cookie);
