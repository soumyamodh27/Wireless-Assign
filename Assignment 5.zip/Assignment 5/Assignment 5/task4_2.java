response.sendRedirect("profile.jsp?sessionId=" + session.getId());
